const fs = require('fs');
const path = require('path');
const { default: makeWASocket, useMultiFileAuthState, downloadMediaMessage, fetchLatestBaileysVersion, jidNormalizedUser, Browsers } = require('@whiskeysockets/baileys');
const pino = require('pino');
const qrcode = require('qrcode-terminal');
const { GoogleGenAI } = require('@google/genai');

const PASTA_SESSAO = 'sessao_alagarecife';
// Número que será pareado (formato internacional, só dígitos). Ex.: 558194853786
const NUMERO_PAREAMENTO = process.env.PAIRING_NUMBER || '';

// ⚠️ Prefira definir a variável de ambiente GEMINI_API_KEY.
const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY || "AQ.Ab8RN6IOWx8BeU0iauQ70PZvRlw4_Mj0oY3ctAFSNn4cLWAPNg",
    httpOptions: {
        retryOptions: { attempts: 1 },
        timeout: 25000
    }
});

// Modelos testados e funcionando com esta chave (12/11/2026).
// gemini-3.8-flash e gemini-3.7-flash estão com 503 e travavam o bot.
const MODELOS = ['gemini-3.6-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite'];
const LIMITE_MODELO_MS = 20000;
// Mensagens entregues da fila offline chegam como "append"; aceitamos se forem recentes.
const JANELA_APPEND_MS = 10 * 60 * 1000;

// ===== Trava de instância única =====
// Sem isso, rodar "node gemini.js" duas vezes gera erro 440 (conflito de sessão)
// e as mensagens se perdem no vaivém de reconexões.
const ARQUIVO_TRAVA = path.join(__dirname, 'bot.lock');

function pidEstaVivo(pid) {
    if (!pid || pid === process.pid) return false;
    try {
        process.kill(pid, 0);
        return true;
    } catch (erro) {
        return erro.code === 'EPERM';
    }
}

function adquirirTrava() {
    let pidExistente = null;
    try {
        pidExistente = Number(fs.readFileSync(ARQUIVO_TRAVA, 'utf8').trim());
    } catch {
        // sem arquivo de trava: segue normalmente
    }

    if (pidEstaVivo(pidExistente)) {
        console.error(`\n❌ Já existe uma instância do bot rodando (PID ${pidExistente}).`);
        console.error('   Feche a outra janela/processo antes de iniciar de novo.');
        console.error(`   Se ela travou, rode:  Stop-Process -Id ${pidExistente} -Force\n`);
        process.exit(1);
    }

    fs.writeFileSync(ARQUIVO_TRAVA, String(process.pid));
}

function liberarTrava() {
    try {
        if (Number(fs.readFileSync(ARQUIVO_TRAVA, 'utf8').trim()) === process.pid) {
            fs.unlinkSync(ARQUIVO_TRAVA);
        }
    } catch {
        // arquivo já removido
    }
}

process.on('exit', liberarTrava);
process.on('SIGINT', () => { liberarTrava(); process.exit(0); });
process.on('SIGTERM', () => { liberarTrava(); process.exit(0); });


const bancoUsuarios = {
    "5581988887777@s.whatsapp.net": { 
        nome: "José", 
        bairro: "Ibura", 
        rua: "Rua Principal", 
        destino: "Centro do Recife" 
    }
};

process.on('unhandledRejection', (erro) => {
    console.error("❌ Promessa rejeitada sem tratamento:", erro?.message || erro);
});

function comTempoLimite(promessa, ms, descricao) {
    let timer;
    const limite = new Promise((_, rejeitar) => {
        timer = setTimeout(() => rejeitar(new Error(`Tempo esgotado (${ms}ms) em ${descricao}`)), ms);
    });
    return Promise.race([promessa, limite]).finally(() => clearTimeout(timer));
}

function unwrapMensagem(message) {
    return message.ephemeralMessage?.message ||
           message.viewOnceMessage?.message ||
           message.viewOnceMessageV2?.message ||
           message.documentWithCaptionMessage?.message ||
           message.deviceSentMessage?.message ||
           message.editedMessage?.message ||
           message;
}

// Busca o clima REAL de Recife
async function buscarAlertasRegiao(bairro) {
    console.log(`🔎 Consultando clima real de Recife para o bairro: ${bairro}...`);
    try {
        const url = "https://api.open-meteo.com/v1/forecast?latitude=-8.0476&longitude=-34.8770"
            + "&current=temperature_2m,precipitation,rain,weather_code&timezone=America%2FRecife";
        const resposta = await fetch(url);
        if (!resposta.ok) throw new Error(`HTTP ${resposta.status}`);

        const dados = await resposta.json();
        const atual = dados.current;
        const chovendo = (atual.precipitation || 0) > 0 || (atual.rain || 0) > 0;

        console.log(`🌦️ Clima obtido: ${atual.temperature_2m}°C | Chuva: ${atual.precipitation}mm`);

        return [
            `Temperatura atual em Recife: ${atual.temperature_2m}°C.`,
            `Chuva neste exato momento: ${atual.precipitation} mm (${chovendo ? 'Está chovendo agora' : 'Tempo seco, sem chuva no momento'}).`,
            `Data e hora local: ${new Date().toLocaleString('pt-BR', { timeZone: 'America/Recife' })}.`
        ];
    } catch (erro) {
        console.log("⚠️ Falha ao buscar clima na Open-Meteo:", erro.message);
        return ["Tempo estável em Recife no momento, sem registro de chuva forte."];
    }
}

// Chama o Gemini tentando um modelo por vez, com timeout e fallback
async function gerarComReserva(conteudo, config, rotulo) {
    let ultimoErro;

    for (let i = 0; i < MODELOS.length; i++) {
        const modeloAtual = MODELOS[i];
        const inicio = Date.now();

        try {
            const response = await comTempoLimite(
                ai.models.generateContent({ model: modeloAtual, contents: conteudo, config }),
                LIMITE_MODELO_MS,
                modeloAtual
            );
            console.log(`✅ ${rotulo} respondeu com ${modeloAtual} em ${Date.now() - inicio}ms`);
            return response.text;
        } catch (erro) {
            ultimoErro = erro;
            console.log(`⚠️ ${rotulo}: ${modeloAtual} falhou (${erro.status || erro.message}) em ${Date.now() - inicio}ms`);
            if (i < MODELOS.length - 1) await new Promise(resolve => setTimeout(resolve, 800));
        }
    }

    throw ultimoErro;
}

async function processarAssistenteTexto(usuario, mensagemTexto) {
    const dadosTempoReal = await buscarAlertasRegiao(usuario.bairro);

    const systemPrompt = `
        Você é a 'AlagaIA', assistente de mobilidade urbana em Recife.
        PERFIL DO MORADOR: Nome: ${usuario.nome} | Bairro: ${usuario.bairro} | Destino: ${usuario.destino}
        DADOS METEOROLÓGICOS REAIS DE AGORA EM RECIFE:
        ${dadosTempoReal.join("\n")}
        REGRAS:
        1. Baseie-se APENAS nos dados reais acima. Nunca invente alertas de chuva se estiver marcado "Tempo seco".
        2. Se não estiver chovendo, tranquilize o morador de forma natural e calma.
        3. Escreva respostas curtas (máximo 3 a 4 linhas) no estilo WhatsApp.
    `;

    return gerarComReserva(
        mensagemTexto,
        { systemInstruction: systemPrompt, temperature: 0.3 },
        "texto"
    );
}

async function processarVisaoAlagamento(base64Image, mimeType) {
    const promptVisao = `
        Analise esta foto enviada por um morador em Recife.
        Responda de forma calma e curta (máximo 4 linhas) no estilo WhatsApp indicando:
        1. O Nível de Risco (🟢 Leve, 🟡 Moderado ou 🔴 Crítico).
        2. O que aparece na imagem (se há água acumulada, profundidade aparente ou trânsito).
        3. Uma orientação rápida de segurança para quem está no local.
    `;

    return gerarComReserva(
        [
            { inlineData: { data: base64Image, mimeType: mimeType } },
            promptVisao
        ],
        { temperature: 0.3 },
        "visão"
    );
}

let tentativasReconexao = 0;

async function iniciarBot() {
    console.log("⏳ Iniciando conexão com o WhatsApp...");
    const { state, saveCreds } = await useMultiFileAuthState(PASTA_SESSAO);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        auth: state,
        logger: pino({ level: process.env.BAILEYS_LOG || 'silent' }),
        browser: Browsers.ubuntu('Chrome'),
        syncFullHistory: false,
        markOnlineOnConnect: true
    });

    sock.ev.on('creds.update', saveCreds);

    // Controle de loop (não responder as próprias respostas) e deduplicação
    const idsEnviados = new Set();
    const idsProcessados = new Set();

    const guardarId = (set, id, limite) => {
        set.add(id);
        if (set.size > limite) set.delete(set.values().next().value);
    };

    const enviar = async (jid, conteudo) => {
        const enviada = await sock.sendMessage(jid, conteudo);
        if (enviada?.key?.id) guardarId(idsEnviados, enviada.key.id, 500);
        return enviada;
    };

    let codigoPedido = false;

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr && !state.creds.registered) {
            if (NUMERO_PAREAMENTO) {
                if (!codigoPedido) {
                    codigoPedido = true;
                    try {
                        const codigo = await sock.requestPairingCode(NUMERO_PAREAMENTO);
                        console.log(`\n🔑 CÓDIGO DE PAREAMENTO: ${codigo}`);
                        console.log(`   No celular do número ${NUMERO_PAREAMENTO}:`);
                        console.log(`   WhatsApp > Configurações > Dispositivos conectados > Conectar dispositivo > Conectar com número de telefone\n`);
                    } catch (erro) {
                        codigoPedido = false;
                        console.error("❌ Erro ao gerar código de pareamento:", erro.message || erro);
                    }
                }
            } else {
                console.log('\n📌 Escaneie o QR Code abaixo no seu WhatsApp:\n');
                qrcode.generate(qr, { small: true });
            }
        }

        if (connection === 'close') {
            const statusCode = lastDisconnect?.error?.output?.statusCode;

            if (statusCode === 440) {
                console.error("\n❌ Conexão substituída (440): outra instância está usando esta mesma sessão do WhatsApp.");
                console.error("   Esta instância vai encerrar para não entrar em loop. Deixe apenas UMA rodando.\n");
                liberarTrava();
                process.exit(1);
            }

            if (statusCode === 401) {
                console.error("\n❌ Sessão desconectada pelo WhatsApp (401).");
                console.error("   Apague a pasta 'sessao_alagarecife' e pareie novamente.\n");
                liberarTrava();
                process.exit(1);
            }

            tentativasReconexao += 1;
            const espera = Math.min(30000, 3000 * Math.pow(1.6, tentativasReconexao - 1));
            console.log(`⚠️ Conexão fechada (Código: ${statusCode}). Reconectando em ${Math.round(espera / 1000)}s (tentativa ${tentativasReconexao})...`);
            setTimeout(iniciarBot, espera);
        } else if (connection === 'open') {
            tentativasReconexao = 0;
            console.log('\n🚀 AlagaRecife Bot PRONTO e ouvindo mensagens!');
            console.log(`   Conta conectada: ${sock.user?.id || '?'} | LID: ${sock.user?.lid || '-'}\n`);
        }
    });

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        for (const msg of messages) {
            try {
                const id = msg?.key?.id;

                if (!msg?.message) {
                    console.log(`⚠️ Evento sem conteúdo (type=${type}) — provável falha de descriptografia.`);
                    continue;
                }

                if (id && idsProcessados.has(id)) continue;
                if (id) guardarId(idsProcessados, id, 2000);

                const remetente = msg.key.remoteJid;
                const conteudo = Object.keys(msg.message).join(',');
                console.log(`📥 [${type}] jid=${remetente} alt=${msg.key.remoteJidAlt || '-'} fromMe=${msg.key.fromMe} conteudo=${conteudo}`);

                // 'notify' = mensagem nova. 'append' pode ser fila offline: aceita se for recente.
                const tsMs = Number(msg.messageTimestamp?.toNumber?.() ?? msg.messageTimestamp) * 1000;
                const recente = tsMs > 0 && (Date.now() - tsMs) < JANELA_APPEND_MS;
                if (type !== 'notify' && !recente) {
                    console.log(`   ↳ ignorada (type=${type} e fora da janela recente)`);
                    continue;
                }

                if (!remetente) continue;

                if (remetente.endsWith('@g.us')) {
                    console.log('   ↳ ignorada (mensagem de grupo)');
                    continue;
                }

                if (remetente.endsWith('@newsletter') || remetente === 'status@broadcast') {
                    console.log('   ↳ ignorada (canal/status)');
                    continue;
                }

                const m = unwrapMensagem(msg.message);

                const textoRecebido = m.conversation ||
                                      m.extendedTextMessage?.text ||
                                      m.imageMessage?.caption || "";

                if (!textoRecebido && !m.imageMessage) {
                    console.log(`   ↳ ignorada (sem texto/foto: ${Object.keys(m).join(',')})`);
                    continue;
                }

                const meuJid = jidNormalizedUser(sock.user?.id || '');
                const meuLid = jidNormalizedUser(sock.user?.lid || '');
                const autoConversa = remetente === meuJid || remetente === meuLid;

                if (msg.key.fromMe) {
                    // Eco das respostas que o próprio bot enviou
                    if (id && idsEnviados.has(id)) continue;

                    // Mensagem sua em outra conversa: só responde com "!teste"
                    if (!autoConversa && !textoRecebido.trim().toLowerCase().startsWith('!teste')) {
                        console.log('   ↳ ignorada (fromMe em outra conversa; use "!teste")');
                        continue;
                    }
                }

                // Em conversas via LID o JID do remetente vem em remoteJidAlt
                const jidIdentidade = (remetente.endsWith('@lid') && msg.key.remoteJidAlt) ? msg.key.remoteJidAlt : remetente;
                const usuario = bancoUsuarios[jidIdentidade] || { nome: "Morador", bairro: "Ibura", rua: "Rua Principal", destino: "Recife" };

                // CASO A: FOTO
                if (m.imageMessage) {
                    if (!m.imageMessage.mediaKey) continue;

                    await enviar(remetente, { text: '🔍 *AlagaIA:* Analisando a imagem enviada...' });
                    try {
                        const buffer = await downloadMediaMessage({ key: msg.key, message: m }, 'buffer', {});
                        const base64Image = buffer.toString('base64');
                        const mimeType = m.imageMessage.mimetype || 'image/jpeg';

                        const relatorioVisual = await processarVisaoAlagamento(base64Image, mimeType);
                        await enviar(remetente, { text: relatorioVisual });
                        console.log("✅ Análise de imagem enviada!");
                    } catch (error) {
                        console.error("❌ Erro ao processar imagem:", error.message || error);
                        await enviar(remetente, { text: 'Desculpa, ocorreu um erro ao analisar a tua foto.' });
                    }
                }
                // CASO B: TEXTO
                else if (textoRecebido) {
                    const perguntaLimpa = textoRecebido.replace(/^!teste/i, '').trim() || "Olá, como está o tempo?";

                    try {
                        console.log("🤖 Consultando o Gemini...");
                        await sock.sendPresenceUpdate('composing', remetente);

                        const respostaAssistente = await processarAssistenteTexto(usuario, perguntaLimpa);

                        await new Promise(resolve => setTimeout(resolve, 1000));
                        await sock.sendPresenceUpdate('paused', remetente);

                        await enviar(remetente, { text: respostaAssistente });
                        console.log("✅ Resposta enviada com sucesso!");
                    } catch (error) {
                        console.error("❌ ERRO NA API DO GEMINI:", error.message || error);
                        await enviar(remetente, { text: 'Desculpa, tive um problema ao consultar a IA neste momento.' });
                    }
                }
            } catch (erro) {
                console.error("❌ Erro ao processar mensagem:", erro?.message || erro);
            }
        }
    });
}

if (require.main === module) {
    adquirirTrava();
    iniciarBot();
}

module.exports = { buscarAlertasRegiao, processarAssistenteTexto, processarVisaoAlagamento };
